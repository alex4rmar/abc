#!/usr/bin/env bash



killall -q polybar

polybar menu -c ~/.config/polybar/menu.ini &

polybar space -c ~/.config/polybar/space.ini &

polybar modular -c ~/.config/polybar/modular.ini &

polybar system -c ~/.config/polybar/system.ini &

